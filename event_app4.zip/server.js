const express = require('express');
const oracledb = require('oracledb');
const cors = require('cors');
const path = require('path');

const app = express();
const port = 3000;

// Oracle connection configuration
const dbConfig = {
  user: 'admin',
  password: 'SID12345',
  connectString: 'database-2.c3s2isyemuno.us-east-1.rds.amazonaws.com:1521/LAVANYA'
};

// Connect to Oracle
async function connectToDB() {
  try {
    await oracledb.createPool(dbConfig);
    console.log('Connected to Oracle Database');
  } catch (err) {
    console.error('Error connecting to Oracle Database:', err);
  }
}

connectToDB();

// Middleware to parse JSON requests
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json()); // Parse JSON requests

// CORS middleware
app.use(cors());

// Serve the HTML file for events
app.get('/events', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'events.html'));
});

// Route to fetch venues
app.get('/venues', async (req, res) => {
  let connection;
  try {
    connection = await oracledb.getConnection();
    const result = await connection.execute('SELECT VENUE_NAME, ADDRESS, CAPACITY, CONTACT_PERSON, CONTACT_EMAIL, CONTACT_PHONE FROM Venues');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching venues:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});

// Route to add a new venue
app.post('/venues', async (req, res) => {
  const { venueName, address, capacity, contactPerson, contactEmail, contactPhone } = req.body;
  const newVenue = [venueName, address, capacity, contactPerson, contactEmail, contactPhone];
  let connection;
  try {
    connection = await oracledb.getConnection();
    await connection.execute(
      `INSERT INTO Venues (Venue_Name, Address, Capacity, Contact_Person, Contact_Email, Contact_Phone)
      VALUES (:1, :2, :3, :4, :5, :6)`,
      newVenue
    );
    await connection.commit();
    console.log('Venue added successfully');
    res.sendStatus(200);
  } catch (err) {
    console.error('Error adding venue:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});

// Route to fetch venues
app.get('/event', async (req, res) => {
  let connection;
  try {
    connection = await oracledb.getConnection();
    const result = await connection.execute('SELECT E.EVENT_NAME, E.EVENT_DATE, E.EVENT_TIME, V.VENUE_NAME, E.DESCRIPTION FROM EVENTS E LEFT JOIN VENUES V ON E.VENUE_ID = V.VENUE_ID');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching events:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});

// Route to add a new event
app.post('/event', async (req, res) => {
  const { eventName, eventDate, eventTime, venueName, description } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(); // Get a connection from the pool

    // Retrieve venue_id
    const venueIdQuery = `SELECT VENUE_ID FROM VENUES WHERE VENUE_NAME = :venueName`;
    const venueIdResult = await connection.execute(venueIdQuery, [venueName]);
    const venue_id = venueIdResult.rows[0][0];

    // Insert event
    const insertQuery = `
      INSERT INTO Events (Event_Name, Event_Date, Event_Time, Venue_ID, Description)
      VALUES (:1, TO_DATE(:2, 'YYYY-MM-DD'), TO_TIMESTAMP(:3, 'YYYY-MM-DD"T"HH24:MI:SS'), :4, :5)`;
    const formattedTime = eventTime + ':00'; // Assuming eventTime is in HH:MM format
      
    const newEvent = [eventName, eventDate, `${eventDate}T${formattedTime}`, venue_id, description];
    await connection.execute(insertQuery, newEvent);

    // Commit transaction
    await connection.commit();

    console.log('Event added successfully');
    res.sendStatus(200);
  } catch (err) {
    if (connection) {
      try {
        // Rollback transaction on error
        await connection.execute(`ROLLBACK`);
      } catch (rollbackErr) {
        console.error('Error rolling back transaction:', rollbackErr);
      }
    }
    console.error('Error adding event:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close(); // Release the connection back to the pool
      } catch (closeErr) {
        console.error('Error closing connection:', closeErr);
      }
    }
  }
});

// Route to fetch participants
app.get('/participant', async (req, res) => {
  let connection;
  try {
    connection = await oracledb.getConnection();
    const result = await connection.execute('SELECT * from PARTICIPANTS');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching participant:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});

// Route to add a new participant
app.post('/participant', async (req, res) => {
  const { Name, Email, Phone, Organization } = req.body;
  console.log("req.body: ",req.body);
  let connection;

  try {
    connection = await oracledb.getConnection(); // Get a connection from the pool

    // Insert participant
    const insertQuery = `
      INSERT INTO PARTICIPANTS (NAME, EMAIL, PHONE, ORGANIZATION)
      VALUES (:1, :2, :3, :4)`;
      
    const newParticipant = [Name, Email, Phone, Organization];
    await connection.execute(insertQuery, newParticipant);

    // Commit transaction
    await connection.execute(`COMMIT`);

    console.log('Participant added successfully');
    res.sendStatus(200);
  } catch (err) {
    if (connection) {
      try {
        // Rollback transaction on error
        await connection.execute(`ROLLBACK`);
      } catch (rollbackErr) {
        console.error('Error rolling back transaction:', rollbackErr);
      }
    }
    console.error('Error adding participant:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close(); 
      } catch (closeErr) {
        console.error('Error closing connection:', closeErr);
      }
    }
  }
});


// Route to fetch budgets
app.get('/budgets', async (req, res) => {
  let connection;
  try {
    connection = await oracledb.getConnection();
    const result = await connection.execute('SELECT B.BUDGET_ID, E.EVENT_NAME, B.TOTAL_BUDGET, B.ALLOCATION_DETAILS, B.EXPENDITURE FROM BUDGET B LEFT JOIN Events E ON E.EVENT_ID = B.EVENT_ID');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching budgets:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});

app.post('/budgets', async (req, res) => {
  const { eventName, totalBudget, allocationDetails, expenditure } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(); // Get a connection from the pool

    // Retrieve event_id
    const event_id_query = `SELECT EVENT_ID FROM EVENTS WHERE EVENT_NAME = :EVENT_Name`;
    const eventIdResult = await connection.execute(event_id_query, [eventName]);
    const event_id = eventIdResult.rows[0][0];

    // Insert event
    const insertQuery = `
      INSERT INTO BUDGET (EVENT_ID, TOTAL_BUDGET, ALLOCATION_DETAILS, EXPENDITURE)
      VALUES (:1, :2, :3, :4)`;
      
    const newEvent = [event_id, totalBudget, allocationDetails, expenditure];
    await connection.execute(insertQuery, newEvent);

    // Commit transaction
    await connection.commit();

    console.log('Budget added successfully');
    res.sendStatus(200);
  } catch (err) {
    if (connection) {
      try {
        // Rollback transaction on error
        await connection.execute(`ROLLBACK`);
      } catch (rollbackErr) {
        console.error('Error rolling back transaction:', rollbackErr);
      }
    }
    console.error('Error adding event:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close(); // Release the connection back to the pool
      } catch (closeErr) {
        console.error('Error closing connection:', closeErr);
      }
    }
  }
});

// Route to fetch registrations
app.get('/registration', async (req, res) => {
  let connection;
  try {
    connection = await oracledb.getConnection();
    const result = await connection.execute('SELECT R.REGISTRATION_ID, E.EVENT_NAME, P.NAME, R.REGISTRATION_DATE, R.STATUS FROM REGISTRATIONS R LEFT JOIN EVENTS E ON E.EVENT_ID = R.EVENT_ID LEFT JOIN PARTICIPANTS P ON P.PARTICIPANT_ID = R.PARTICIPANT_ID');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching registration:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});

app.post('/registration', async (req, res) => {
  const { eventName, participantName, registrationDate, status } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(); // Get a connection from the pool

    // Retrieve event_id
    const event_id_query = `SELECT EVENT_ID FROM EVENTS WHERE EVENT_NAME = :EVENT_Name`;
    const eventIdResult = await connection.execute(event_id_query, [eventName]);
    const event_id = eventIdResult.rows[0][0];

    // Retrieve participant_id
    const participant_id_query = `SELECT PARTICIPANT_ID FROM PARTICIPANTS WHERE NAME = :participantName`;
    const participantIdResult = await connection.execute(participant_id_query, [participantName]);
    const participant_id = participantIdResult.rows[0][0];
    console.log("event_id", event_id)


    // Insert event
    const insertQuery = `
      INSERT INTO REGISTRATIONS (EVENT_ID, PARTICIPANT_ID, REGISTRATION_DATE, Status)
      VALUES (:1, :2, TO_DATE(:3, 'YYYY-MM-DD'), :4)`;
      
    const newEvent = [event_id, participant_id, registrationDate, status];
    await connection.execute(insertQuery, newEvent);

    // Commit transaction
    await connection.commit();

    console.log('Registration added successfully');
    res.sendStatus(200);
  } catch (err) {
    if (connection) {
      try {
        // Rollback transaction on error
        await connection.execute(`ROLLBACK`);
      } catch (rollbackErr) {
        console.error('Error rolling back transaction:', rollbackErr);
      }
    }
    console.error('Error adding event:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close(); // Release the connection back to the pool
      } catch (closeErr) {
        console.error('Error closing connection:', closeErr);
      }
    }
  }
});

// Route to fetch feedbacks
app.get('/feedbacks', async (req, res) => {
  let connection;
  try {
    connection = await oracledb.getConnection();
    const result = await connection.execute('SELECT F.FEEDBACK_ID, E.EVENT_NAME, P.NAME, F.RATING, F.COMMENTS FROM FEEDBACK F LEFT JOIN EVENTS E ON E.EVENT_ID = F.EVENT_ID LEFT JOIN PARTICIPANTS P ON P.PARTICIPANT_ID = F.PARTICIPANT_ID');
    res.json(result.rows);
  } catch (err) {
    console.error('Error fetching events:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close();
      } catch (err) {
        console.error('Error closing connection:', err);
      }
    }
  }
});

app.post('/feedbacks', async (req, res) => {
  const { eventName, participantName, rating, comments } = req.body;
  let connection;

  try {
    connection = await oracledb.getConnection(); // Get a connection from the pool

    // Retrieve event_id
    const event_id_query = `SELECT EVENT_ID FROM EVENTS WHERE EVENT_NAME = :EVENT_Name`;
    const eventIdResult = await connection.execute(event_id_query, [eventName]);
    const event_id = eventIdResult.rows[0][0];

    // Retrieve participant_id
    const participant_id_query = `SELECT PARTICIPANT_ID FROM PARTICIPANTS WHERE NAME = :participantName`;
    const participantIdResult = await connection.execute(participant_id_query, [participantName]);
    const participant_id = participantIdResult.rows[0][0];


    // Insert event
    const insertQuery = `
      INSERT INTO FEEDBACK (EVENT_ID, PARTICIPANT_ID, RATING, COMMENTS)
      VALUES (:1, :2, :3, :4)`;
      
    const newEvent = [event_id, participant_id, rating, comments];
    await connection.execute(insertQuery, newEvent);

    // Commit transaction
    await connection.commit();

    console.log('Feedback added successfully');
    res.sendStatus(200);
  } catch (err) {
    if (connection) {
      try {
        // Rollback transaction on error
        await connection.execute(`ROLLBACK`);
      } catch (rollbackErr) {
        console.error('Error rolling back transaction:', rollbackErr);
      }
    }
    console.error('Error adding event:', err);
    res.status(500).send('Internal Server Error');
  } finally {
    if (connection) {
      try {
        await connection.close(); // Release the connection back to the pool
      } catch (closeErr) {
        console.error('Error closing connection:', closeErr);
      }
    }
  }
});


// Start the server
app.listen(port, () => {
  console.log(`Server is listening on port ${port}`);
});
